/**
 * RGthrifth — Main JavaScript
 * Premium Local Hoodie Brand
 * 
 * Fitur:
 * - Loading screen
 * - Dark mode (localStorage)
 * - Navbar scroll & hamburger menu
 * - Cart (localStorage)
 * - Favorites (localStorage)
 * - Scroll reveal animation
 * - Toast notifications
 * - Scroll to top button
 */

/* ============================================
   UTILITIES
   ============================================ */

/** Format harga ke Rupiah */
const formatPrice = (price) =>
  new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(price);

/** Buat bintang rating dari angka */
const renderStars = (rating) => {
  let stars = '';
  for (let i = 1; i <= 5; i++) {
    const filled = i <= Math.floor(rating);
    stars += `<svg class="star" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" fill="${filled ? '#f59e0b' : '#e5e7eb'}"/></svg>`;
  }
  return stars;
};

/** Buat badge html */
const renderBadge = (badge) => {
  if (!badge) return '';
  const map = { Bestseller: 'blue', New: 'green', Hot: 'red', Sale: 'orange', Limited: 'purple' };
  const color = map[badge] || 'blue';
  return `<span class="badge badge-${color}">${badge}</span>`;
};

/* ============================================
   LOADING SCREEN
   ============================================ */
const initLoadingScreen = () => {
  const screen = document.getElementById('loading-screen');
  if (!screen) return;
  setTimeout(() => {
    screen.classList.add('hidden');
    // Trigger scroll reveal setelah loading selesai
    setTimeout(triggerReveal, 100);
  }, 1500);
};

/* ============================================
   DARK MODE
   ============================================ */
const initDarkMode = () => {
  // Ambil state dari localStorage atau default ke sistem
  const saved = localStorage.getItem('rgthrifth-theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const isDark = saved ? saved === 'dark' : prefersDark;

  if (isDark) document.documentElement.setAttribute('data-theme', 'dark');

  // Toggle button handler
  const toggleBtns = document.querySelectorAll('[data-dark-toggle]');
  toggleBtns.forEach(btn => {
    updateDarkIcon(btn, isDark);
    btn.addEventListener('click', () => {
      const currentDark = document.documentElement.getAttribute('data-theme') === 'dark';
      const newDark = !currentDark;
      document.documentElement.setAttribute('data-theme', newDark ? 'dark' : 'light');
      localStorage.setItem('rgthrifth-theme', newDark ? 'dark' : 'light');
      toggleBtns.forEach(b => updateDarkIcon(b, newDark));
    });
  });
};

const updateDarkIcon = (btn, isDark) => {
  btn.innerHTML = isDark
    ? `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>`
    : `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>`;
};

/* ============================================
   NAVBAR
   ============================================ */
const initNavbar = () => {
  const navbar = document.querySelector('.navbar');
  const hamburger = document.querySelector('.hamburger');
  const mobileMenu = document.querySelector('.mobile-menu');

  if (!navbar) return;

  // Scroll handler
  window.addEventListener('scroll', () => {
    navbar.classList.toggle('scrolled', window.scrollY > 20);
    updateScrollTopBtn();
  }, { passive: true });

  // Hamburger toggle
  if (hamburger && mobileMenu) {
    hamburger.addEventListener('click', () => {
      hamburger.classList.toggle('open');
      mobileMenu.classList.toggle('open');
    });

    // Close on link click
    mobileMenu.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => {
        hamburger.classList.remove('open');
        mobileMenu.classList.remove('open');
      });
    });
  }

  // Set active link
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.navbar-links a, .mobile-menu a').forEach(a => {
    const href = a.getAttribute('href') || '';
    if (href === currentPage || (href === 'index.html' && currentPage === '')) {
      a.classList.add('active');
    }
  });
};

/* ============================================
   SCROLL REVEAL
   ============================================ */
const triggerReveal = () => {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
};

/* ============================================
   SCROLL TO TOP
   ============================================ */
const scrollTopBtn = document.getElementById('scroll-top');

const updateScrollTopBtn = () => {
  if (!scrollTopBtn) return;
  scrollTopBtn.classList.toggle('visible', window.scrollY > 400);
};

if (scrollTopBtn) {
  scrollTopBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

/* ============================================
   TOAST SYSTEM
   ============================================ */
const showToast = (message, type = 'success') => {
  const container = document.querySelector('.toast-container') || (() => {
    const el = document.createElement('div');
    el.className = 'toast-container';
    document.body.appendChild(el);
    return el;
  })();

  const icons = {
    success: `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>`,
    error: `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
    info: `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`
  };

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<div class="toast-icon">${icons[type]}</div><span class="toast-message">${message}</span>`;
  container.appendChild(toast);

  requestAnimationFrame(() => {
    requestAnimationFrame(() => toast.classList.add('show'));
  });

  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 400);
  }, 3000);
};

/* ============================================
   CART SYSTEM (localStorage)
   ============================================ */
let cart = JSON.parse(localStorage.getItem('rgthrifth-cart') || '[]');

const saveCart = () => {
  localStorage.setItem('rgthrifth-cart', JSON.stringify(cart));
  updateCartBadge();
  renderCartItems();
};

const updateCartBadge = () => {
  const total = cart.reduce((sum, item) => sum + item.qty, 0);
  document.querySelectorAll('.cart-badge').forEach(badge => {
    badge.textContent = total;
    badge.classList.toggle('visible', total > 0);
  });
};

const addToCart = (product, size = 'M') => {
  const existing = cart.find(i => i.id === product.id && i.size === size);
  if (existing) {
    existing.qty++;
  } else {
    cart.push({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      size,
      qty: 1
    });
  }
  saveCart();
  showToast(`${product.name} ditambahkan ke cart!`);
};

const removeFromCart = (id, size) => {
  cart = cart.filter(i => !(i.id === id && i.size === size));
  saveCart();
};

const updateQty = (id, size, delta) => {
  const item = cart.find(i => i.id === id && i.size === size);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) removeFromCart(id, size);
  else saveCart();
};

const getCartTotal = () => cart.reduce((sum, i) => sum + i.price * i.qty, 0);

const renderCartItems = () => {
  const body = document.querySelector('.cart-drawer-body');
  if (!body) return;

  if (cart.length === 0) {
    body.innerHTML = `
      <div class="cart-empty">
        <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" opacity="0.3"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
        <p>Cart kamu kosong</p>
        <a href="product.html" class="btn btn-primary btn-sm">Lihat Produk</a>
      </div>`;
    updateCartSummary();
    return;
  }

  body.innerHTML = cart.map(item => `
    <div class="cart-item">
      <img src="${item.image}" alt="${item.name}" class="cart-item-img">
      <div class="cart-item-info">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-size">Ukuran: ${item.size}</div>
        <div class="cart-item-price">${formatPrice(item.price)}</div>
        <div class="cart-item-qty">
          <button class="qty-btn" onclick="updateQty(${item.id}, '${item.size}', -1)">−</button>
          <span class="qty-num">${item.qty}</span>
          <button class="qty-btn" onclick="updateQty(${item.id}, '${item.size}', 1)">+</button>
        </div>
      </div>
      <button class="btn-icon cart-item-remove" onclick="removeFromCart(${item.id}, '${item.size}')" title="Hapus">
        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>
      </button>
    </div>
  `).join('');

  updateCartSummary();
};

const updateCartSummary = () => {
  const total = getCartTotal();
  const shipping = total >= 350000 ? 0 : 25000;
  const grand = total + shipping;

  const summaryEl = document.querySelector('.cart-summary');
  if (!summaryEl) return;

  summaryEl.innerHTML = `
    <div class="cart-summary-row">
      <span>Subtotal</span><span>${formatPrice(total)}</span>
    </div>
    <div class="cart-summary-row">
      <span>Ongkir</span><span>${shipping === 0 ? '<span style="color:#10b981">Gratis</span>' : formatPrice(shipping)}</span>
    </div>
    <div class="cart-summary-row total">
      <span>Total</span><span>${formatPrice(grand)}</span>
    </div>`;

  const waBtn = document.querySelector('.cart-wa-btn');
  if (waBtn) {
    if (cart.length === 0) {
      waBtn.style.opacity = '0.5';
      waBtn.style.pointerEvents = 'none';
    } else {
      waBtn.style.opacity = '1';
      waBtn.style.pointerEvents = 'auto';
      waBtn.onclick = () => openWhatsApp();
    }
  }
};

const openWhatsApp = () => {
  const items = cart.map(i => `• ${i.name} (${i.size}) x${i.qty} = ${formatPrice(i.price * i.qty)}`).join('\n');
  const total = formatPrice(getCartTotal());
  const msg = encodeURIComponent(`Halo RGthrifth! Saya mau order:\n\n${items}\n\n*Total: ${total}*\n\nMohon konfirmasinya ya 🙏`);
  window.open(`https://wa.me/6285123456789?text=${msg}`, '_blank');
};

const initCart = () => {
  // Cart drawer
  const cartBtns = document.querySelectorAll('[data-cart-open]');
  const backdrop = document.querySelector('.cart-drawer-backdrop');
  const drawer = document.querySelector('.cart-drawer');
  const closeBtn = document.querySelector('[data-cart-close]');

  const openCart = () => {
    backdrop?.classList.add('open');
    drawer?.classList.add('open');
    document.body.style.overflow = 'hidden';
  };

  const closeCart = () => {
    backdrop?.classList.remove('open');
    drawer?.classList.remove('open');
    document.body.style.overflow = '';
  };

  cartBtns.forEach(btn => btn.addEventListener('click', openCart));
  backdrop?.addEventListener('click', closeCart);
  closeBtn?.addEventListener('click', closeCart);

  updateCartBadge();
  renderCartItems();
};

/* ============================================
   FAVORITES SYSTEM (localStorage)
   ============================================ */
let favorites = JSON.parse(localStorage.getItem('rgthrifth-favorites') || '[]');

const saveFavorites = () => {
  localStorage.setItem('rgthrifth-favorites', JSON.stringify(favorites));
};

const toggleFavorite = (productId, btn) => {
  const idx = favorites.indexOf(productId);
  if (idx === -1) {
    favorites.push(productId);
    btn?.classList.add('favorited');
    showToast('Ditambahkan ke favorit!', 'info');
  } else {
    favorites.splice(idx, 1);
    btn?.classList.remove('favorited');
    showToast('Dihapus dari favorit', 'info');
  }
  saveFavorites();
};

const isFavorited = (id) => favorites.includes(id);

/* ============================================
   PRODUCT CARD RENDERER
   ============================================ */
const createProductCard = (product) => {
  const fav = isFavorited(product.id);
  const card = document.createElement('div');
  card.className = 'product-card reveal';
  card.innerHTML = `
    <div class="product-card-image">
      <img src="${product.image}" alt="${product.name}" loading="lazy">
      ${product.badge ? `<div class="product-card-badge">${renderBadge(product.badge)}</div>` : ''}
      <div class="product-card-actions">
        <button class="product-action-btn fav-btn ${fav ? 'favorited' : ''}" data-id="${product.id}" title="Favorit">
          <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="${fav ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
        </button>
        <button class="product-action-btn" data-quick-view="${product.id}" title="Quick View">
          <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
        </button>
      </div>
    </div>
    <div class="product-card-body">
      <div class="product-card-category">${product.category}</div>
      <div class="product-card-name">${product.name}</div>
      <div class="product-card-rating">
        <div class="stars">${renderStars(product.rating)}</div>
        <span class="rating-count">(${product.reviews})</span>
      </div>
      <div class="product-card-footer">
        <div class="product-price">
          <span class="price-current">${formatPrice(product.price)}</span>
          ${product.originalPrice ? `<span class="price-original">${formatPrice(product.originalPrice)}</span>` : ''}
        </div>
        <button class="btn-cart" data-add-cart="${product.id}" title="Tambah ke Cart">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
        </button>
      </div>
    </div>`;

  // Event listeners
  card.querySelector('.fav-btn').addEventListener('click', (e) => {
    e.stopPropagation();
    toggleFavorite(product.id, e.currentTarget);
  });

  card.querySelector('[data-quick-view]')?.addEventListener('click', (e) => {
    e.stopPropagation();
    openModal(product);
  });

  card.querySelector('[data-add-cart]').addEventListener('click', (e) => {
    e.stopPropagation();
    addToCart(product);
  });

  card.addEventListener('click', () => openModal(product));

  return card;
};

/* ============================================
   PRODUCT MODAL
   ============================================ */
let activeProduct = null;
let selectedSize = 'M';

const openModal = (product) => {
  activeProduct = product;
  selectedSize = product.sizes?.[1] || product.sizes?.[0] || 'M';

  const backdrop = document.querySelector('.modal-backdrop');
  if (!backdrop) return;

  const img = backdrop.querySelector('.modal-image');
  const category = backdrop.querySelector('.modal-category');
  const name = backdrop.querySelector('.modal-name');
  const desc = backdrop.querySelector('.modal-desc');
  const priceEl = backdrop.querySelector('.modal-price-current');
  const origEl = backdrop.querySelector('.modal-price-original');
  const sizeContainer = backdrop.querySelector('.size-options');
  const ratingEl = backdrop.querySelector('.modal-rating');

  if (img) img.src = product.image;
  if (img) img.alt = product.name;
  if (category) category.textContent = product.category;
  if (name) name.textContent = product.name;
  if (desc) desc.textContent = product.description;
  if (priceEl) priceEl.textContent = formatPrice(product.price);
  if (origEl) origEl.textContent = product.originalPrice ? formatPrice(product.originalPrice) : '';
  if (ratingEl) ratingEl.innerHTML = `<div class="stars">${renderStars(product.rating)}</div> <span>(${product.reviews} ulasan)</span>`;

  if (sizeContainer && product.sizes) {
    sizeContainer.innerHTML = product.sizes.map(s => `
      <button class="size-btn ${s === selectedSize ? 'active' : ''}" data-size="${s}">${s}</button>
    `).join('');

    sizeContainer.querySelectorAll('.size-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        selectedSize = btn.dataset.size;
        sizeContainer.querySelectorAll('.size-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      });
    });
  }

  backdrop.classList.add('open');
  document.body.style.overflow = 'hidden';
};

const initModal = () => {
  const backdrop = document.querySelector('.modal-backdrop');
  const closeBtn = document.querySelector('.modal-close');
  const addBtn = document.querySelector('[data-modal-add-cart]');
  const waBtn = document.querySelector('[data-modal-wa]');

  if (!backdrop) return;

  backdrop.addEventListener('click', (e) => {
    if (e.target === backdrop) {
      backdrop.classList.remove('open');
      document.body.style.overflow = '';
    }
  });

  closeBtn?.addEventListener('click', () => {
    backdrop.classList.remove('open');
    document.body.style.overflow = '';
  });

  addBtn?.addEventListener('click', () => {
    if (activeProduct) {
      addToCart(activeProduct, selectedSize);
      backdrop.classList.remove('open');
      document.body.style.overflow = '';
    }
  });

  waBtn?.addEventListener('click', () => {
    if (!activeProduct) return;
    const msg = encodeURIComponent(`Halo RGthrifth! Saya mau tanya/order:\n\n*${activeProduct.name}* ukuran ${selectedSize}\nHarga: ${formatPrice(activeProduct.price)}\n\nApakah stok tersedia?`);
    window.open(`https://wa.me/6285123456789?text=${msg}`, '_blank');
  });
};

/* ============================================
   FETCH PRODUCTS
   ============================================ */
const fetchProducts = async () => {
  try {
    const basePath = document.documentElement.dataset.basePath || '/';
    const response = await fetch(`${basePath}products.json`);
    if (!response.ok) throw new Error('Failed to fetch');
    const data = await response.json();
    return data;
  } catch (err) {
    console.error('Error fetching products:', err);
    return { products: [], testimonials: [] };
  }
};

/* ============================================
   HOME PAGE
   ============================================ */
const initHomePage = async () => {
  const featuredGrid = document.getElementById('featured-products');
  const testimonialsGrid = document.getElementById('testimonials-grid');
  if (!featuredGrid && !testimonialsGrid) return;

  const data = await fetchProducts();

  // Featured: ambil 4 produk teratas
  if (featuredGrid) {
    const featured = data.products.slice(0, 4);
    featured.forEach(p => featuredGrid.appendChild(createProductCard(p)));
    setTimeout(triggerReveal, 100);
  }

  // Testimonials
  if (testimonialsGrid) {
    const testimonials = data.testimonials;
    testimonialsGrid.innerHTML = testimonials.map(t => `
      <div class="testimonial-card reveal">
        <div class="testimonial-top">
          <img src="${t.avatar}" alt="${t.name}" class="testimonial-avatar">
          <div class="testimonial-stars">${renderStars(t.rating)}</div>
        </div>
        <p class="testimonial-text">"${t.comment}"</p>
        <div class="testimonial-author">
          <div class="testimonial-name">${t.name} · ${t.city}</div>
          <div class="testimonial-meta">${t.product} · ${t.date}</div>
        </div>
      </div>
    `).join('');
    setTimeout(triggerReveal, 200);
  }
};

/* ============================================
   PRODUCT PAGE
   ============================================ */
const initProductPage = async () => {
  const grid = document.getElementById('products-grid');
  if (!grid) return;

  const data = await fetchProducts();
  let products = [...data.products];
  let activeFilter = 'all';
  let searchQuery = '';

  const render = () => {
    let filtered = products.filter(p => {
      const matchFilter = activeFilter === 'all' || p.category === activeFilter;
      const matchSearch = p.name.toLowerCase().includes(searchQuery) ||
                          p.category.toLowerCase().includes(searchQuery) ||
                          p.tags.some(t => t.includes(searchQuery));
      return matchFilter && matchSearch;
    });

    grid.innerHTML = '';
    const count = document.getElementById('products-count');
    if (count) count.textContent = `${filtered.length} produk`;

    if (filtered.length === 0) {
      grid.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">🔍</div>
          <h3>Produk tidak ditemukan</h3>
          <p>Coba kata kunci atau filter lain</p>
        </div>`;
      return;
    }

    filtered.forEach(p => grid.appendChild(createProductCard(p)));
    setTimeout(triggerReveal, 50);
  };

  // Search realtime
  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      searchQuery = e.target.value.toLowerCase().trim();
      render();
    });
  }

  // Filter chips
  document.querySelectorAll('[data-filter]').forEach(chip => {
    chip.addEventListener('click', () => {
      activeFilter = chip.dataset.filter;
      document.querySelectorAll('[data-filter]').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      render();
    });
  });

  render();
};

/* ============================================
   CONTACT PAGE
   ============================================ */
const initContactPage = () => {
  const form = document.getElementById('contact-form');
  if (!form) return;

  // Simpan data user terakhir
  const savedName = localStorage.getItem('rgthrifth-last-name') || '';
  const savedEmail = localStorage.getItem('rgthrifth-last-email') || '';
  const nameInput = form.querySelector('#contact-name');
  const emailInput = form.querySelector('#contact-email');

  if (nameInput && savedName) nameInput.value = savedName;
  if (emailInput && savedEmail) emailInput.value = savedEmail;

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const name = nameInput?.value.trim();
    const email = emailInput?.value.trim();

    // Simpan data ke localStorage
    if (name) localStorage.setItem('rgthrifth-last-name', name);
    if (email) localStorage.setItem('rgthrifth-last-email', email);

    // Simulasi submit
    const submitBtn = form.querySelector('[type="submit"]');
    submitBtn.textContent = 'Mengirim...';
    submitBtn.disabled = true;

    setTimeout(() => {
      form.style.display = 'none';
      const success = document.getElementById('form-success');
      if (success) {
        success.classList.add('visible');
      }
    }, 1500);
  });
};

/* ============================================
   DASHBOARD PAGE
   ============================================ */
const ADMIN_PRODUCTS_KEY = 'rgthrifth-admin-products';

const getAdminProducts = async () => {
  const saved = localStorage.getItem(ADMIN_PRODUCTS_KEY);
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch {
      localStorage.removeItem(ADMIN_PRODUCTS_KEY);
    }
  }

  const data = await fetchProducts();
  const products = data.products || [];
  localStorage.setItem(ADMIN_PRODUCTS_KEY, JSON.stringify(products));
  return products;
};

const saveAdminProducts = (products) => {
  localStorage.setItem(ADMIN_PRODUCTS_KEY, JSON.stringify(products));
};

const getNextProductId = (products) => Math.max(0, ...products.map((p) => p.id || 0)) + 1;

const bindAdminProductActions = () => {
  document.querySelectorAll('[data-admin-edit]').forEach((button) => {
    button.addEventListener('click', () => editAdminProduct(Number(button.dataset.adminEdit)));
  });

  document.querySelectorAll('[data-admin-delete]').forEach((button) => {
    button.addEventListener('click', () => deleteAdminProduct(Number(button.dataset.adminDelete)));
  });
};

const showAdminProductForm = (product = null) => {
  const wrapper = document.getElementById('admin-product-form-wrapper');
  const form = document.getElementById('admin-product-form');
  if (!wrapper || !form) return;

  form.reset();
  form.dataset.editing = product ? 'true' : 'false';
  form.querySelector('#admin-product-id').value = product?.id || '';
  form.querySelector('#admin-product-name').value = product?.name || '';
  form.querySelector('#admin-product-price').value = product?.price || '';
  form.querySelector('#admin-product-original-price').value = product?.originalPrice || '';
  form.querySelector('#admin-product-stock').value = product?.stock || '';
  form.querySelector('#admin-product-badge').value = product?.badge || '';
  form.querySelector('#admin-product-image').value = product?.image || '';
  form.querySelector('#admin-product-description').value = product?.description || '';

  wrapper.classList.remove('hidden');
  form.scrollIntoView({ behavior: 'smooth', block: 'start' });
};

const hideAdminProductForm = () => {
  const wrapper = document.getElementById('admin-product-form-wrapper');
  if (!wrapper) return;
  wrapper.classList.add('hidden');
};

const renderAdminProducts = async (searchQuery = '') => {
  const products = await getAdminProducts();
  const filtered = products.filter((product) => product.name.toLowerCase().includes(searchQuery.toLowerCase()));
  const tbody = document.getElementById('admin-products-table-body');
  const countEl = document.getElementById('admin-products-count');
  const dashboardCountLabel = document.getElementById('dashboard-products-count');

  if (!tbody || !countEl) return;

  countEl.textContent = filtered.length;
  if (dashboardCountLabel) dashboardCountLabel.textContent = `${products.length} produk aktif`;

  if (filtered.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="5" style="padding:.9rem 0;color:var(--text-muted)">Tidak ada produk yang sesuai.</td>
      </tr>`;
    return;
  }

  tbody.innerHTML = filtered
    .map((product) => `
      <tr>
        <td>${product.name}</td>
        <td>${formatPrice(product.price)}</td>
        <td>${product.stock}</td>
        <td>${product.badge || '-'}</td>
        <td>
          <button type="button" class="btn btn-secondary btn-sm" data-admin-edit="${product.id}">Edit</button>
          <button type="button" class="btn btn-secondary btn-sm" data-admin-delete="${product.id}" style="margin-left:.5rem;background:rgba(239,68,68,.08);color:#ef4444;border-color:rgba(239,68,68,.15);">Hapus</button>
        </td>
      </tr>
    `)
    .join('');

  bindAdminProductActions();
};

const handleAdminProductFormSubmit = async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const formData = new FormData(form);
  const id = Number(formData.get('id')) || null;
  const name = String(formData.get('name') || '').trim();
  const price = Number(formData.get('price'));
  const originalPrice = Number(formData.get('originalPrice')) || 0;
  const stock = Number(formData.get('stock'));
  const badge = String(formData.get('badge') || '').trim();
  const image = String(formData.get('image') || '').trim();
  const description = String(formData.get('description') || '').trim();

  if (!name || Number.isNaN(price) || Number.isNaN(stock) || !image || !description) {
    showToast('Lengkapi semua kolom produk yang dibutuhkan.', 'error');
    return;
  }

  const products = await getAdminProducts();
  if (id) {
    const index = products.findIndex((product) => product.id === id);
    if (index !== -1) {
      products[index] = {
        ...products[index],
        name,
        price,
        originalPrice,
        stock,
        badge,
        image,
        description,
        category: 'hoodie',
      };
      saveAdminProducts(products);
      showToast('Produk berhasil diperbarui.');
    }
  } else {
    products.push({
      id: getNextProductId(products),
      name,
      price,
      originalPrice,
      stock,
      badge,
      image,
      description,
      category: 'hoodie',
      rating: 0,
      reviews: 0,
      tags: ['hoodie'],
    });
    saveAdminProducts(products);
    showToast('Produk baru berhasil ditambahkan.');
  }

  hideAdminProductForm();
  renderAdminProducts(document.getElementById('admin-product-search')?.value || '');
};

const editAdminProduct = async (id) => {
  const products = await getAdminProducts();
  const product = products.find((item) => item.id === id);
  if (!product) return;
  showAdminProductForm(product);
};

const deleteAdminProduct = async (id) => {
  if (!window.confirm('Hapus produk ini? Tindakan ini tidak dapat dibatalkan.')) return;
  const products = await getAdminProducts();
  const updated = products.filter((product) => product.id !== id);
  saveAdminProducts(updated);
  showToast('Produk berhasil dihapus.');
  renderAdminProducts(document.getElementById('admin-product-search')?.value || '');
};

const initDashboardPage = async () => {
  const statsGrid = document.querySelector('.stats-grid');
  if (!statsGrid) return;

  const adminProducts = await getAdminProducts();

  renderSalesChart();
  renderTopProducts(adminProducts);
  renderAdminProducts();

  const adminForm = document.getElementById('admin-product-form');
  const adminAddBtn = document.getElementById('admin-add-product-btn');
  const adminCancelBtn = document.getElementById('admin-cancel-btn');
  const adminSearch = document.getElementById('admin-product-search');

  if (adminForm) adminForm.addEventListener('submit', handleAdminProductFormSubmit);
  if (adminAddBtn) adminAddBtn.addEventListener('click', () => showAdminProductForm());
  if (adminCancelBtn) adminCancelBtn.addEventListener('click', hideAdminProductForm);
  if (adminSearch) adminSearch.addEventListener('input', (e) => renderAdminProducts(e.target.value.trim()));

  document.querySelectorAll('.sidebar-link').forEach((link) => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      document.querySelectorAll('.sidebar-link').forEach((l) => l.classList.remove('active'));
      link.classList.add('active');
    });
  });
};

const renderSalesChart = () => {
  const container = document.querySelector('.chart-bars');
  if (!container) return;

  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul'];
  const revenues = [65, 80, 72, 90, 85, 110, 130];
  const orders = [45, 58, 52, 67, 62, 85, 98];
  const maxRev = Math.max(...revenues);

  container.innerHTML = months.map((m, i) => `
    <div class="chart-bar-group" title="${m}: ${revenues[i]}% revenue">
      <div class="chart-bar revenue" style="height: ${(revenues[i] / maxRev) * 80}%; margin-bottom: 2px;"></div>
      <div class="chart-bar orders" style="height: ${(orders[i] / maxRev) * 80}%;"></div>
    </div>
  `).join('');

  // Tambahkan label bulan
  const labelContainer = document.querySelector('.chart-month-labels');
  if (labelContainer) {
    labelContainer.innerHTML = months.map(m => `<span style="flex:1;text-align:center;font-size:.68rem;color:var(--text-muted)">${m}</span>`).join('');
  }
};

const renderTopProducts = async (products) => {
  const container = document.getElementById('top-products-list');
  if (!container || !products) return;

  const top = products.slice(0, 5);
  container.innerHTML = top.map((p, i) => `
    <div class="top-product-item">
      <div class="top-product-rank ${i === 0 ? 'top' : ''}">${i + 1}</div>
      <img src="${p.image}" alt="${p.name}" class="top-product-img">
      <div class="top-product-info">
        <div class="top-product-name">${p.name}</div>
        <div class="top-product-sales">${p.reviews} terjual</div>
      </div>
      <div class="top-product-revenue">${formatPrice(p.price * Math.floor(p.reviews * 0.8))}</div>
    </div>
  `).join('');
};

/* ============================================
   MARQUEE DUPLICATE
   ============================================ */
const initMarquee = () => {
  const track = document.querySelector('.marquee-track');
  if (!track) return;
  // Duplicate untuk seamless loop
  track.innerHTML += track.innerHTML;
};

/* ============================================
   NUMBER COUNTER ANIMATION
   ============================================ */
const animateCounter = (el, target, duration = 1500) => {
  const start = 0;
  const startTime = performance.now();

  const update = (currentTime) => {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.floor(eased * target).toLocaleString('id-ID');
    if (progress < 1) requestAnimationFrame(update);
  };

  requestAnimationFrame(update);
};

const initCounters = () => {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const target = parseInt(el.dataset.count);
        if (!isNaN(target)) animateCounter(el, target);
        observer.unobserve(el);
      }
    });
  }, { threshold: 0.5 });

  document.querySelectorAll('[data-count]').forEach(el => observer.observe(el));
};

/* ============================================
   INIT ALL
   ============================================ */
document.addEventListener('DOMContentLoaded', () => {
  initLoadingScreen();
  initDarkMode();
  initNavbar();
  initCart();
  initModal();
  initMarquee();
  initCounters();
  triggerReveal();

  // Page-specific init
  initHomePage();
  initProductPage();
  initContactPage();
  initDashboardPage();
});

// Expose needed globals
window.updateQty = updateQty;
window.removeFromCart = removeFromCart;
